var class_tra_c_i_demo_r_s_u11p =
[
    [ "initialize", "class_tra_c_i_demo_r_s_u11p.html#a94a8c38a2685c7dd941c79e96d507cbe", null ],
    [ "onBeacon", "class_tra_c_i_demo_r_s_u11p.html#a2d9ac4a5768faaacf9c6a93f89ce66d8", null ],
    [ "onData", "class_tra_c_i_demo_r_s_u11p.html#ac9d01a67de93ec7f9e64ce7c664c370f", null ],
    [ "sendMessage", "class_tra_c_i_demo_r_s_u11p.html#a8ec20e405841c5724bfe8a29b352d580", null ],
    [ "sendWSM", "class_tra_c_i_demo_r_s_u11p.html#afd0f615084c6e709fe10f513e90da6ed", null ],
    [ "annotations", "class_tra_c_i_demo_r_s_u11p.html#af5ccc47f99dbb52ad91ac3426b776d79", null ],
    [ "mobi", "class_tra_c_i_demo_r_s_u11p.html#aff89329eb04939aea7d42d85b69609ea", null ],
    [ "sentMessage", "class_tra_c_i_demo_r_s_u11p.html#a35e81416854eda6fb9897f744b06eb15", null ]
];