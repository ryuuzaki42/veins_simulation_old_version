var _tra_c_i_connection_8cc =
[
    [ "MYDEBUG", "_tra_c_i_connection_8cc.html#a38cc676e6c9f06e021b17e537b7bba1d", null ],
    [ "WANT_WINSOCK2", "_tra_c_i_connection_8cc.html#a105264025fbdfc308077979bc21a5474", null ],
    [ "makeTraCICommand", "_tra_c_i_connection_8cc.html#ab52db5bfe6d9095440c0b0ac309bb99d", null ],
    [ "socket", "_tra_c_i_connection_8cc.html#a6eeefaf3bbdaff6c10cfcd01200016d3", null ]
];