var _tra_c_i_scenario_manager_inet_8cc =
[
    [ "ifInetTraCIMobilityCallNextPosition", "_tra_c_i_scenario_manager_inet_8cc.html#a5049232949eb3445301bc999967c4057", null ],
    [ "ifInetTraCIMobilityCallPreInitialize", "_tra_c_i_scenario_manager_inet_8cc.html#a837d0aa832e73eca6f2ba8c992c919a5", null ]
];