var class_decider_result80211 =
[
    [ "DeciderResult80211", "class_decider_result80211.html#a67b7eb5cb3ddad6136840f6c42399a4a", null ],
    [ "getBitrate", "class_decider_result80211.html#a514a242a3b67f14f7536b6d59e26a7ce", null ],
    [ "getSnr", "class_decider_result80211.html#a2a5d1c65094164e0fad38927a14a4fb2", null ],
    [ "bitrate", "class_decider_result80211.html#ab80f1803479db0321ff8532c9bed815e", null ],
    [ "snr", "class_decider_result80211.html#a1fe1171bdbc17bfca48bcf700472375d", null ]
];