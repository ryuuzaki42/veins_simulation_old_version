var class_veins_1_1_annotation_manager_1_1_polygon =
[
    [ "Polygon", "class_veins_1_1_annotation_manager_1_1_polygon.html#a51bd05eb33c81c7a6a03a8965ee126f1", null ],
    [ "~Polygon", "class_veins_1_1_annotation_manager_1_1_polygon.html#a1dcfe7a88b256284643b9077fec50934", null ],
    [ "AnnotationManager", "class_veins_1_1_annotation_manager_1_1_polygon.html#aaedce5ff10318ebddfdb8d1acede6d7a", null ],
    [ "color", "class_veins_1_1_annotation_manager_1_1_polygon.html#ad3797331970cc20e828cf6974ff51b1f", null ],
    [ "coords", "class_veins_1_1_annotation_manager_1_1_polygon.html#a8dd7c8dc28082148a4e6a6d34395fdae", null ]
];