var class_breakpoint_pathloss_model =
[
    [ "BreakpointPathlossModel", "class_breakpoint_pathloss_model.html#a4d07c21c43a837163d3d5a4ebd6f533a", null ],
    [ "filterSignal", "class_breakpoint_pathloss_model.html#a50fed0d02ee407b1ab602a6c203cfd83", null ],
    [ "isActiveAtDestination", "class_breakpoint_pathloss_model.html#a40f8c0d27eba086bc3a2f6f65af1f37c", null ],
    [ "isActiveAtOrigin", "class_breakpoint_pathloss_model.html#a1f36f2c1056bc9365838cc0d89d5e441", null ],
    [ "alpha1", "class_breakpoint_pathloss_model.html#a9308bf633a9048ae42b7b004d718606f", null ],
    [ "alpha2", "class_breakpoint_pathloss_model.html#ab2b41fdd2300b115a75c9647a7cd7e9b", null ],
    [ "breakpointDistance", "class_breakpoint_pathloss_model.html#a8f5df99a4fac21e39f985b8af0d9412c", null ],
    [ "carrierFrequency", "class_breakpoint_pathloss_model.html#a15f631e677b586706c16f910187c5b69", null ],
    [ "debug", "class_breakpoint_pathloss_model.html#aa9f8dbeb8e7e0f3a9200652d1f81a88c", null ],
    [ "pathlosses", "class_breakpoint_pathloss_model.html#a0c6ce678120579025519343c8a0974c3", null ],
    [ "PL01", "class_breakpoint_pathloss_model.html#aaf5084c5a5dc83b37a468e5813a8191d", null ],
    [ "PL01_real", "class_breakpoint_pathloss_model.html#abaedae8f705d49e1c7fc547eede38c62", null ],
    [ "PL02", "class_breakpoint_pathloss_model.html#a31580babd35b18cbd87a7ac30b71693f", null ],
    [ "PL02_real", "class_breakpoint_pathloss_model.html#aea3fe4a5fdc2aead5a651791b07688d3", null ],
    [ "playgroundSize", "class_breakpoint_pathloss_model.html#a615b284b0cc9cc289daf530152cff657", null ],
    [ "useTorus", "class_breakpoint_pathloss_model.html#a06dc26cafc4157dabdf10303395f96be", null ]
];