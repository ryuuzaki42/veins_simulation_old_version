var class_base_battery =
[
    [ "BaseBattery", "class_base_battery.html#a6bd8a2ebca6b85e25984fae7a5faa8fb", null ],
    [ "BaseBattery", "class_base_battery.html#a2aa922227a7f1d1c1e8188aaea1a16e5", null ],
    [ "draw", "class_base_battery.html#a4ac1773aef7363fc880a9689706ccc99", null ],
    [ "estimateResidualAbs", "class_base_battery.html#a15862e04dfa8b40082ecccff79b14ca0", null ],
    [ "estimateResidualRelative", "class_base_battery.html#a67c0d2c69f13b6c7ca4a24b23257d83f", null ],
    [ "getState", "class_base_battery.html#ab9afb1ddcea070ee4fdf9807521cc806", null ],
    [ "getVoltage", "class_base_battery.html#a20ee7721d8da961e3493da63a0fafb81", null ],
    [ "registerDevice", "class_base_battery.html#a6b2ac07e8d11823bdd239de2bfa4563a", null ]
];