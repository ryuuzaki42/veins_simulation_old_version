var class_passed_message =
[
    [ "direction_t", "class_passed_message.html#a11c83e74aa007c495b32ec3ed4953a50", [
      [ "INCOMING", "class_passed_message.html#a11c83e74aa007c495b32ec3ed4953a50a43c42d4afa45cd04736e0d59167260a4", null ],
      [ "OUTGOING", "class_passed_message.html#a11c83e74aa007c495b32ec3ed4953a50a862e80d4bad52c451a413eef983c16ae", null ]
    ] ],
    [ "gates_t", "class_passed_message.html#a7738b6f08855f784d1012de87fbfd9e6", [
      [ "UPPER_DATA", "class_passed_message.html#a7738b6f08855f784d1012de87fbfd9e6adf76d3ca7bb9a62bed70965639d59859", null ],
      [ "UPPER_CONTROL", "class_passed_message.html#a7738b6f08855f784d1012de87fbfd9e6aea991e99dac6c91c9e3e89f902f1075d", null ],
      [ "LOWER_DATA", "class_passed_message.html#a7738b6f08855f784d1012de87fbfd9e6a97265ac51f333c88508670c5d3f5ded9", null ],
      [ "LOWER_CONTROL", "class_passed_message.html#a7738b6f08855f784d1012de87fbfd9e6afb379d2a15495f1ef2f290dc9ac97299", null ]
    ] ],
    [ "direction", "class_passed_message.html#af55219a6ed1e656af091cb7583467f5b", null ],
    [ "fromModule", "class_passed_message.html#a6c340595cb29a4e8a4c55ea0503dffad", null ],
    [ "gateType", "class_passed_message.html#a41f11b3139f3552cf2de3bb648c1ff55", null ],
    [ "kind", "class_passed_message.html#ab4e2bf6d2317196af7e9c98ed2c406a6", null ],
    [ "name", "class_passed_message.html#a8a4eb44ad1e43205d1881fec0c00a6d7", null ]
];