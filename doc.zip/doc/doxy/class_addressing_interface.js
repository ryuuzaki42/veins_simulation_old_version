var class_addressing_interface =
[
    [ "myMacAddr", "class_addressing_interface.html#a7d81614e8dea6e3a7316184e6b9e959c", null ],
    [ "myNetwAddr", "class_addressing_interface.html#a3f4172beef51056ebc815246b6c9d651", null ]
];