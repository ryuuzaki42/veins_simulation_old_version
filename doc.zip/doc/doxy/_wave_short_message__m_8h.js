var _wave_short_message__m_8h =
[
    [ "WaveShortMessage", "class_wave_short_message.html", "class_wave_short_message" ],
    [ "MSGC_VERSION", "_wave_short_message__m_8h.html#a77f5ea746b531cbdbc322a93741e33a6", null ],
    [ "doPacking", "_wave_short_message__m_8h.html#ae74b14e21ab85bdfeeca766a8ce81a74", null ],
    [ "doUnpacking", "_wave_short_message__m_8h.html#a6cbe959450c1c1aaa3a979594bfe7d49", null ]
];