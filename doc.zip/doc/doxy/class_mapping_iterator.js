var class_mapping_iterator =
[
    [ "~MappingIterator", "class_mapping_iterator.html#afd541639ad951794e64291812bc1a1a0", null ],
    [ "setValue", "class_mapping_iterator.html#a68c80b10de257d7cfd68f49bfd6a2cbe", null ]
];