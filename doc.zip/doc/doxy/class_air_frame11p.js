var class_air_frame11p =
[
    [ "AirFrame11p", "class_air_frame11p.html#a7f35dba37995cdb2fb5b0f380b9e445e", null ],
    [ "AirFrame11p", "class_air_frame11p.html#a2b3e68356c5dcf9538a1cf5fa42457db", null ],
    [ "~AirFrame11p", "class_air_frame11p.html#ab50da7666fe019f06bec4801bd864cef", null ],
    [ "copy", "class_air_frame11p.html#a50a72f449f996cade0d4625823cc34c5", null ],
    [ "dup", "class_air_frame11p.html#a042810dd386765917473bf9b9572a483", null ],
    [ "getUnderSensitivity", "class_air_frame11p.html#ae9af854b9c8237077618f82a3db6be54", null ],
    [ "getWasTransmitting", "class_air_frame11p.html#a8d2568edd1c3308580ce581d64a14951", null ],
    [ "operator=", "class_air_frame11p.html#a9f63926aabf4ca26d7a253da273a0693", null ],
    [ "operator==", "class_air_frame11p.html#af22a1142529951461e8ed5f5318d8a5f", null ],
    [ "parsimPack", "class_air_frame11p.html#a053a61df242466fb76f8fb3e66661615", null ],
    [ "parsimUnpack", "class_air_frame11p.html#acf108af30c840181cb327fc7db85fb36", null ],
    [ "setUnderSensitivity", "class_air_frame11p.html#ad9c2571b011c2b081ad1689218f0d0ac", null ],
    [ "setWasTransmitting", "class_air_frame11p.html#aa00aa01ba7302cd1078a5a51f6bc5cb5", null ],
    [ "underSensitivity_var", "class_air_frame11p.html#ab95fd64b3946bb61542d5f5d879af776", null ],
    [ "wasTransmitting_var", "class_air_frame11p.html#a8b073d735fff5b53d31b829097079b79", null ]
];