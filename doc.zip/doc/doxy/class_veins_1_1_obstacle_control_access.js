var class_veins_1_1_obstacle_control_access =
[
    [ "ObstacleControlAccess", "class_veins_1_1_obstacle_control_access.html#a4a1c00dc526e36376d9ad0cb16c319ae", null ],
    [ "getIfExists", "class_veins_1_1_obstacle_control_access.html#aa91c56b9eab7ff107096256d861b7ca4", null ]
];