var class_p_e_r_model =
[
    [ "PERModel", "class_p_e_r_model.html#a18f4f1553b984e711602679b49fc434c", null ],
    [ "filterSignal", "class_p_e_r_model.html#ab571e93f422b0e6a299cee2c2b886bc0", null ],
    [ "packetErrorRate", "class_p_e_r_model.html#a32ced82d925f432ef880595a3d202be8", null ]
];