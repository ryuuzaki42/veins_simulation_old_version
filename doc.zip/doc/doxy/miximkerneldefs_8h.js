var miximkerneldefs_8h =
[
    [ "MIXIM_SIGNAL_BATTERY_CHANGE_NAME", "miximkerneldefs_8h.html#a96f94c37521741f38fd049c30ddf9817", null ],
    [ "MIXIM_SIGNAL_DROPPEDPACKET_NAME", "miximkerneldefs_8h.html#aad55d45b2982ce696ce5dc1692690627", null ],
    [ "MIXIM_SIGNAL_HOSTSTATE_NAME", "miximkerneldefs_8h.html#a3ec3b1ea6bc9444723e83dd40ec0e3bd", null ],
    [ "MIXIM_SIGNAL_MOBANMSG_NAME", "miximkerneldefs_8h.html#a7483fc5c00a5a73c605d34fc48202a47", null ],
    [ "MIXIM_SIGNAL_MOBILITY_CHANGE_NAME", "miximkerneldefs_8h.html#ae69fff18982d6706f61a783d2c76e3c3", null ],
    [ "MIXIM_SIGNAL_PACKET_NAME", "miximkerneldefs_8h.html#ad6bd863f498a055ad7936e8606f52456", null ],
    [ "MIXIM_SIGNAL_PASSEDMSG_NAME", "miximkerneldefs_8h.html#ae77f3d9270863d9320e03453f8b05724", null ],
    [ "MIXIM_SIGNAL_UWBIRPACKET_NAME", "miximkerneldefs_8h.html#aabad51446826904506303465155af970", null ],
    [ "MIXIM_VERSION", "miximkerneldefs_8h.html#a7ba1ea0c3476b05a9e1f8fe56cc3f958", null ]
];