var class_two_ray_interference_model =
[
    [ "Mapping", "class_two_ray_interference_model_1_1_mapping.html", "class_two_ray_interference_model_1_1_mapping" ],
    [ "TwoRayInterferenceModel", "class_two_ray_interference_model.html#aa307745f89b85c3818babbe4ff613c6a", null ],
    [ "~TwoRayInterferenceModel", "class_two_ray_interference_model.html#ab2fd59f8ff378897fcbf2ab4a7a3d81a", null ],
    [ "filterSignal", "class_two_ray_interference_model.html#a4488ba8c6127ff2e016edaa6bbd6a4c0", null ],
    [ "debug", "class_two_ray_interference_model.html#af42413a25e44da60e4e79ab402f7c12f", null ],
    [ "epsilon_r", "class_two_ray_interference_model.html#a759b4daf5d7ee63761487a327cdf765b", null ]
];