var class_phy_to_mac_control_info =
[
    [ "PhyToMacControlInfo", "class_phy_to_mac_control_info.html#a8e9300c49e9f955c4b5333da109143d4", null ],
    [ "~PhyToMacControlInfo", "class_phy_to_mac_control_info.html#a5b56a9f0cf2b87496f6d19df98216bf5", null ],
    [ "getDeciderResult", "class_phy_to_mac_control_info.html#a695fcb4091796018a3315486acafc9b0", null ],
    [ "result", "class_phy_to_mac_control_info.html#a1dc106d6290a2f4f18b4281e14077545", null ]
];