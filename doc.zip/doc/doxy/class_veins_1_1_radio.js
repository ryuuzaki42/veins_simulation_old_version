var class_veins_1_1_radio =
[
    [ "RadioState", "class_veins_1_1_radio.html#afab1f516f9defc9c79e022c4f0d13267", [
      [ "RX", "class_veins_1_1_radio.html#afab1f516f9defc9c79e022c4f0d13267a85301d7d7e53978ceb1d1bcd986ceb11", null ],
      [ "TX", "class_veins_1_1_radio.html#afab1f516f9defc9c79e022c4f0d13267a801f851998c6c935794b02b51c4a564f", null ],
      [ "SLEEP", "class_veins_1_1_radio.html#afab1f516f9defc9c79e022c4f0d13267af7a031c37e397e9cb27fa719a0602f16", null ],
      [ "SWITCHING", "class_veins_1_1_radio.html#afab1f516f9defc9c79e022c4f0d13267aa3a2ccc5df99f1f1784a24ff231fcfb4", null ],
      [ "NUM_RADIO_STATES", "class_veins_1_1_radio.html#afab1f516f9defc9c79e022c4f0d13267a3545d50f62a2fbfdc733dc0c8bd73f74", null ]
    ] ],
    [ "~Radio", "class_veins_1_1_radio.html#a9fb63e8ebc78c18b4eb5a8040d684174", null ],
    [ "Radio", "class_veins_1_1_radio.html#ae01993661828f9efbb5053a78227789e", null ],
    [ "cleanAnalogueModelUntil", "class_veins_1_1_radio.html#a25501a63aaa78e00dda4e5b868874407", null ],
    [ "endSwitch", "class_veins_1_1_radio.html#aceb966be7e36e87068ae3424de8a5928", null ],
    [ "getAnalogueModel", "class_veins_1_1_radio.html#a38a6c78b55f1442108b44a0bd27abb9f", null ],
    [ "getCurrentChannel", "class_veins_1_1_radio.html#a6e7fa250ec1b1793c51931a7cb7ae914", null ],
    [ "getCurrentState", "class_veins_1_1_radio.html#aa6255c987dcff98f53fb9eed5e056d42", null ],
    [ "makeRSAMEntry", "class_veins_1_1_radio.html#a0cdbbabf0ca4bab58eed854b22bb60f2", null ],
    [ "mapStateToAtt", "class_veins_1_1_radio.html#a78f899bc34a9ff0a67d887d166c4651d", null ],
    [ "setCurrentChannel", "class_veins_1_1_radio.html#a8304dc1fea7754a1cd9c26713e39f234", null ],
    [ "setSwitchTime", "class_veins_1_1_radio.html#aed80922c736427067f27669c87aaf4f8", null ],
    [ "setTrackingModeTo", "class_veins_1_1_radio.html#a803442f32c2eced5bda170cd3a9b5772", null ],
    [ "switchTo", "class_veins_1_1_radio.html#aab434b342c42f1dbfa1df3640afbb4b0", null ],
    [ "currentChannel", "class_veins_1_1_radio.html#a1ac015184bd8d52e3ea781c16092da6e", null ],
    [ "maxAtt", "class_veins_1_1_radio.html#a166724a9c8ebdba2891de103ff4ce38c", null ],
    [ "minAtt", "class_veins_1_1_radio.html#a48211299a136eeacfad9a48137e656ac", null ],
    [ "nbChannels", "class_veins_1_1_radio.html#afa761671ebe5c75db5d957f5283eb7a0", null ],
    [ "nextState", "class_veins_1_1_radio.html#a026c484da4fddae621754b604b017c7c", null ],
    [ "numRadioStates", "class_veins_1_1_radio.html#afd3042e4411274936dc29107ba55a82d", null ],
    [ "radioChannels", "class_veins_1_1_radio.html#ac41ffe7b9281ca385d33da1b29540c53", null ],
    [ "radioStates", "class_veins_1_1_radio.html#aba0037435265ef0fc59ba4d23ae550c9", null ],
    [ "rsam", "class_veins_1_1_radio.html#a73c0c7ea78d32d4782e4025fa5cb0b25", null ],
    [ "state", "class_veins_1_1_radio.html#aa9faccaa07ecb115e054d56a6f6e27f4", null ],
    [ "swTimes", "class_veins_1_1_radio.html#ac54427080e05dad5b76117fc05f6180a", null ]
];