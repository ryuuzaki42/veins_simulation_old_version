var _border_msg__m_8h =
[
    [ "BorderMsg", "class_border_msg.html", "class_border_msg" ],
    [ "MSGC_VERSION", "_border_msg__m_8h.html#a77f5ea746b531cbdbc322a93741e33a6", null ],
    [ "doPacking", "_border_msg__m_8h.html#a22d334b7616278a3df52bb1d909385b8", null ],
    [ "doUnpacking", "_border_msg__m_8h.html#af8a744ea926c5d85163001062af00b8f", null ]
];