var _tra_c_i_buffer_8h =
[
    [ "TraCIBuffer", "class_veins_1_1_tra_c_i_buffer.html", "class_veins_1_1_tra_c_i_buffer" ],
    [ "isBigEndian", "_tra_c_i_buffer_8h.html#a9701754031a4d3de7cc9eeaae1bf9e87", null ]
];