var class_veins_1_1_battery_access =
[
    [ "BatteryAccess", "class_veins_1_1_battery_access.html#a91a34707835f0938bc9c1a1c470ad5fb", null ],
    [ "BatteryAccess", "class_veins_1_1_battery_access.html#af1956d05ad1d5a1b5e3b605e7238c4f6", null ],
    [ "draw", "class_veins_1_1_battery_access.html#a1015e11ad7fc73f62a37e395bf686015", null ],
    [ "drawCurrent", "class_veins_1_1_battery_access.html#af62a4c6ab659f7bebc16cc789c559bc6", null ],
    [ "drawEnergy", "class_veins_1_1_battery_access.html#a603868d7ae89b65da4af161c9470f07f", null ],
    [ "registerWithBattery", "class_veins_1_1_battery_access.html#a2286e83003b2919cbb496260a5b0d009", null ],
    [ "battery", "class_veins_1_1_battery_access.html#a19c053b2525a3e78f911f0433a90628f", null ],
    [ "deviceID", "class_veins_1_1_battery_access.html#a904f5c552f5173ef44ccfd624c3f9b08", null ]
];