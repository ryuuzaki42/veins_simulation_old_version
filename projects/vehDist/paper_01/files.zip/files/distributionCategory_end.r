Resultado da distibuição dos veículos pela ruas
cP = Veículos de Passeio.   cT = Táxi

          Nome da rua    Count cP  Count cT   %% cP           %% cT

   Street_00: 0/0to0/1    cP: 32    cT: 7    %%cP: 0.82     %%cT: 0.18
   Street_01: 0/0to1/0    cP: 7     cT: 2    %%cP: 0.78     %%cT: 0.22
   Street_02: 0/1to0/0    cP: 29    cT: 5    %%cP: 0.85     %%cT: 0.15
   Street_03: 0/1to0/2    cP: 54    cT: 13   %%cP: 0.81     %%cT: 0.19
   Street_04: 0/1to1/1    cP: 53    cT: 9    %%cP: 0.85     %%cT: 0.15
   Street_05: 0/2to0/1    cP: 53    cT: 12   %%cP: 0.82     %%cT: 0.18
   Street_06: 0/2to0/3    cP: 46    cT: 9    %%cP: 0.84     %%cT: 0.16
   Street_07: 0/2to1/2    cP: 30    cT: 8    %%cP: 0.79     %%cT: 0.21
   Street_08: 0/3to0/2    cP: 46    cT: 9    %%cP: 0.84     %%cT: 0.16
   Street_09: 0/3to0/4    cP: 15    cT: 3    %%cP: 0.83     %%cT: 0.17
   Street_10: 0/3to1/3    cP: 24    cT: 10   %%cP: 0.71     %%cT: 0.29
   Street_11: 0/4to0/3    cP: 15    cT: 5    %%cP: 0.75     %%cT: 0.25
   Street_12: 0/4to1/4    cP: 8     cT: 1    %%cP: 0.89     %%cT: 0.11
   Street_13: 1/0to0/0    cP: 8     cT: 4    %%cP: 0.67     %%cT: 0.33
   Street_14: 1/0to1/1    cP: 30    cT: 14   %%cP: 0.68     %%cT: 0.32
   Street_15: 1/0to2/0    cP: 32    cT: 9    %%cP: 0.78     %%cT: 0.22
   Street_16: 1/1to0/1    cP: 53    cT: 9    %%cP: 0.85     %%cT: 0.15
   Street_17: 1/1to1/0    cP: 31    cT: 13   %%cP: 0.7     %%cT: 0.3
   Street_18: 1/1to1/2    cP: 63    cT: 20   %%cP: 0.76     %%cT: 0.24
   Street_19: 1/1to2/1    cP: 59    cT: 8    %%cP: 0.88     %%cT: 0.12
   Street_20: 1/2to0/2    cP: 31    cT: 8    %%cP: 0.79     %%cT: 0.21
   Street_21: 1/2to1/1    cP: 60    cT: 13   %%cP: 0.82     %%cT: 0.18
   Street_22: 1/2to1/3    cP: 83    cT: 17   %%cP: 0.83     %%cT: 0.17
   Street_23: 1/2to2/2    cP: 52    cT: 13   %%cP: 0.8     %%cT: 0.2
   Street_24: 1/3to0/3    cP: 24    cT: 8    %%cP: 0.75     %%cT: 0.25
   Street_25: 1/3to1/2    cP: 83    cT: 11   %%cP: 0.88     %%cT: 0.12
   Street_26: 1/3to1/4    cP: 61    cT: 12   %%cP: 0.84     %%cT: 0.16
   Street_27: 1/3to2/3    cP: 29    cT: 11   %%cP: 0.72     %%cT: 0.28
   Street_28: 1/4to0/4    cP: 7     cT: 3    %%cP: 0.7     %%cT: 0.3
   Street_29: 1/4to1/3    cP: 62    cT: 11   %%cP: 0.85     %%cT: 0.15
   Street_30: 1/4to2/4    cP: 52    cT: 8    %%cP: 0.87     %%cT: 0.13
   Street_31: 2/0to1/0    cP: 32    cT: 11   %%cP: 0.74     %%cT: 0.26
   Street_32: 2/0to2/1    cP: 15    cT: 12   %%cP: 0.56     %%cT: 0.44
   Street_33: 2/0to3/0    cP: 7     cT: 12   %%cP: 0.37     %%cT: 0.63
   Street_34: 2/1to1/1    cP: 63    cT: 14   %%cP: 0.82     %%cT: 0.18
   Street_35: 2/1to2/0    cP: 15    cT: 13   %%cP: 0.54     %%cT: 0.46
   Street_36: 2/1to2/2    cP: 31    cT: 13   %%cP: 0.7     %%cT: 0.3
   Street_37: 2/1to3/1    cP: 50    cT: 8    %%cP: 0.86     %%cT: 0.14
   Street_38: 2/2to1/2    cP: 55    cT: 12   %%cP: 0.82     %%cT: 0.18
   Street_39: 2/2to2/1    cP: 30    cT: 16   %%cP: 0.65     %%cT: 0.35
   Street_40: 2/2to2/3    cP: 37    cT: 10   %%cP: 0.79     %%cT: 0.21
   Street_41: 2/2to3/2    cP: 62    cT: 11   %%cP: 0.85     %%cT: 0.15
   Street_42: 2/3to1/3    cP: 32    cT: 5    %%cP: 0.86     %%cT: 0.14
   Street_43: 2/3to2/2    cP: 38    cT: 14   %%cP: 0.73     %%cT: 0.27
   Street_44: 2/3to2/4    cP: 7     cT: 11   %%cP: 0.39     %%cT: 0.61
   Street_45: 2/3to3/3    cP: 15    cT: 9    %%cP: 0.62     %%cT: 0.38
   Street_46: 2/4to1/4    cP: 56    cT: 8    %%cP: 0.88     %%cT: 0.12
   Street_47: 2/4to2/3    cP: 8     cT: 11   %%cP: 0.42     %%cT: 0.58
   Street_48: 2/4to3/4    cP: 29    cT: 9    %%cP: 0.76     %%cT: 0.24
   Street_49: 3/0to2/0    cP: 8     cT: 13   %%cP: 0.38     %%cT: 0.62
   Street_50: 3/0to3/1    cP: 8     cT: 3    %%cP: 0.73     %%cT: 0.27
   Street_51: 3/0to4/0    cP: 14    cT: 7    %%cP: 0.67     %%cT: 0.33
   Street_52: 3/1to2/1    cP: 56    cT: 11   %%cP: 0.84     %%cT: 0.16
   Street_53: 3/1to3/0    cP: 7     cT: 3    %%cP: 0.7     %%cT: 0.3
   Street_54: 3/1to3/2    cP: 22    cT: 5    %%cP: 0.81     %%cT: 0.19
   Street_55: 3/1to4/1    cP: 14    cT: 6    %%cP: 0.7     %%cT: 0.3
   Street_56: 3/2to2/2    cP: 61    cT: 9    %%cP: 0.87     %%cT: 0.13
   Street_57: 3/2to3/1    cP: 23    cT: 6    %%cP: 0.79     %%cT: 0.21
   Street_58: 3/2to3/3    cP: 37    cT: 5    %%cP: 0.88     %%cT: 0.12
   Street_59: 3/2to4/2    cP: 23    cT: 9    %%cP: 0.72     %%cT: 0.28
   Street_60: 3/3to2/3    cP: 15    cT: 8    %%cP: 0.65     %%cT: 0.35
   Street_61: 3/3to3/2    cP: 39    cT: 7    %%cP: 0.85     %%cT: 0.15
   Street_62: 3/3to3/4    cP: 23    cT: 6    %%cP: 0.79     %%cT: 0.21
   Street_63: 3/3to4/3    cP: 22    cT: 6    %%cP: 0.79     %%cT: 0.21
   Street_64: 3/4to2/4    cP: 32    cT: 7    %%cP: 0.82     %%cT: 0.18
   Street_65: 3/4to3/3    cP: 23    cT: 8    %%cP: 0.74     %%cT: 0.26
   Street_66: 3/4to4/4    cP: 14    cT: 4    %%cP: 0.78     %%cT: 0.22
   Street_67: 4/0to3/0    cP: 16    cT: 9    %%cP: 0.64     %%cT: 0.36
   Street_68: 4/0to4/1    cP: 15    cT: 1    %%cP: 0.94     %%cT: 0.062
   Street_69: 4/1to3/1    cP: 16    cT: 8    %%cP: 0.67     %%cT: 0.33
   Street_70: 4/1to4/0    cP: 15    cT: 3    %%cP: 0.83     %%cT: 0.17
   Street_71: 4/1to4/2    cP: 15    cT: 2    %%cP: 0.88     %%cT: 0.12
   Street_72: 4/2to3/2    cP: 23    cT: 6    %%cP: 0.79     %%cT: 0.21
   Street_73: 4/2to4/1    cP: 15    cT: 5    %%cP: 0.75     %%cT: 0.25
   Street_74: 4/2to4/3    cP: 8     cT: 3    %%cP: 0.73     %%cT: 0.27
   Street_75: 4/3to3/3    cP: 24    cT: 5    %%cP: 0.83     %%cT: 0.17
   Street_76: 4/3to4/2    cP: 7     cT: 3    %%cP: 0.7     %%cT: 0.3
   Street_77: 4/3to4/4    cP: 7     cT: 2    %%cP: 0.78     %%cT: 0.22
   Street_78: 4/4to3/4    cP: 16    cT: 5    %%cP: 0.76     %%cT: 0.24
   Street_79: 4/4to4/3    cP: 8     cT: 1    %%cP: 0.89     %%cT: 0.11

CountTotal: 3100 CountA: 2440    CountB: 660

Porcentagem geral, %%GcP: 0.79    %%GcT: 0.21