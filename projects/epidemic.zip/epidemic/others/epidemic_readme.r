###########################################################

## hex to dec
printf '%d\n' 0xFFFFFFF

## dec to hex
printf '%x\n' 268435455
printf '%X\n' 268435455
printf '%#x\n' 268435455
printf '%#X\n' 268435455
